class Tile

  def initialize(value)
    @value = value
    @given = false 

  end

  def value
    @value
  end

  def given?
    @given 
  end

  def to_s
    if self.value == '0'
      @given = false 
    else
      @given = true 
    end
  end

end