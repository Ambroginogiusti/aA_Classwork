require_relative 'board'
require_relative 'tile'

class Game

  def initialize
    @board = Board.new
  end
  
  def get_val
    puts "enter a number from 1 to 9"
    gets.chomp
  end
  
  def get_pos
    puts "now enter a position in the form of two numbers, e.g. 0 0"
    gets.chomp.split(' ').map!(&:to_i)
  end
  
  def play
    val = self.get_val
    pos = self.get_pos
    # if .to_s(pos)
      @board[pos] = val
    else
      puts "that position is already given"
    end
  end

end