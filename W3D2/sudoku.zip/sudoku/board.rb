require_relative 'tile'

class Board

  attr_reader :grid

  def self.from_file
    grid = File.readlines('puzzles/sudoku1.txt')
    grid.map! do |row|
      row.split('')
    end
    grid
  end

  def initialize
    @grid = Array.new(9) { Array.new(9) { Tile.new("0") } }
  end

  def [](pos)
    row, col = pos
    @grid[row][col]
  end

  def []=(pos, val)
    row, col = pos
    @grid[row][col] = val
  end

  def render
    @grid.each do |row|
      puts row.join('')
    end
  end

  def new_board
    (0...@grid.length).each do |i|
      (0...@grid.length).each do |j|
        grid = Board.from_file
        @grid[i][j] = grid[i][j]
      end
    end
  end

  def row_solved?
    @grid.each do |row|
      if row.uniq? && row.none?('0')
        return true
      else 
        return false
      end
    end
  end

  def col_solved?
    @grid.transpose.each do |row|
      if row.uniq? && row.none?('0')
        return true
      else 
        return false
      end
    end
  end

  def squ_solved?
    temp_arr = []
    (0...@grid.length).each do |i|
      (0...@grid.length).each do |j|
        until temp_arr.length[i] == 3
          temp_arr.push(@grid[i][j])
          return true if temp_arr.flatten.uniq?
        end
        temp_arr = []
      end
    end
    return false
  end

  def solved?
    row_solved? || col_solved? || squares_solved?
  end

end

b = Board.new
puts b.grid