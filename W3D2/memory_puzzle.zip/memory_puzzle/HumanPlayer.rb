class HumanPlayer
  
end