class ComputerPlayer
  
end