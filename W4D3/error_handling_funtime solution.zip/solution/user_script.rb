require_relative 'super_useful'

feed_me_a_fruit

sam = BestFriend.new('Samwise', 50, 'gardening')

sam.talk_about_friendship
sam.do_friendstuff
sam.give_friendship_bracelet
